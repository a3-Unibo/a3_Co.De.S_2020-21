Elefront for Grasshopper in Rhino 6
Alan Tai, Front Inc
11/06/2018

To Install:

ElefrontProperties.rhp
Drag and drop onto your Rhino model view to install.
This is a object property tab in Rhino. Click on any object and the tab will be available at the Object Properties panel. 

